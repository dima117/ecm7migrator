﻿using System.Data;
using ECM7.Migrator.Framework;

namespace $rootnamespace$
{
    [Migration(0)]
    public class $fileinputname$ : Migration
    {
        public override void Apply()
        {
        }

        public override void Revert()
        {
        }
    }
}